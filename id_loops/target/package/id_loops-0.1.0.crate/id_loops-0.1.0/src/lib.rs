pub fn for_loop(start:u8,end:u8){
    for index in start..end{
        println!("{}",index);
    }
}