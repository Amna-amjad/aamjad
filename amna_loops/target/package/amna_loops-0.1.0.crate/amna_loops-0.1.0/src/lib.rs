fn for_loop(){
    for index in 1..10 {
        println!("{}",index);
    }
}